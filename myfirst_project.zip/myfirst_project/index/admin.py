from django.contrib import admin
from .models import about,slider,client

# Register your models here.
admin.site.register(about)
admin.site.register(slider)
admin.site.register(client)