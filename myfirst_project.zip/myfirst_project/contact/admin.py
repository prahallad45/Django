from django.contrib import admin
from .models import contactlist,contactform
# Register your models here.

admin.site.register(contactlist)
admin.site.register(contactform)
